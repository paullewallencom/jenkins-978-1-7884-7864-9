## Section 3: Exercises

### Theory

1. What is the difference between Continuous Integration, Continuous Delivery, and Continuous Deployment?

2. What are the main components of a typical CI workflow? 

3. List and explain some types of tests. 

4. What is the difference between passive notifications and active notifications?

### Practice

1. Replace Slack with another notification channel of your choice (e.g. email, IRC, RSS feeds, etc.). 

2. If you have software project you are working on, try to implement a CI workflow around it that builds, tests, and notifies. Feel free to use the tools you're more familiar with. 
