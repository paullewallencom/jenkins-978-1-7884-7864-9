# start Jenkins at boot time
sudo systemctl start jenkins.service
sudo systemctl enable jenkins.service
