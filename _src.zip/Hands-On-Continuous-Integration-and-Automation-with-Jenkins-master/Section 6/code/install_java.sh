# install java 1.8 on Amazon Linux 
sudo yum update -y
sudo yum install -y java-1.8.0-openjdk-devel 
sudo alternatives --config java
